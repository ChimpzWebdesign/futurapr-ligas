export const products = [
  {
    id: '1',
    title: 'E-book: Marketing Digital Completo',
    description: 'Aprenda todas as estratégias de marketing digital que realmente funcionam. Desde SEO até campanhas pagas, este guia completo vai transformar seu negócio online.',
    longDescription: 'Este e-book abrangente contém mais de 200 páginas de conteúdo prático sobre marketing digital. Você aprenderá sobre SEO, Google Ads, Facebook Ads, email marketing, marketing de conteúdo e muito mais. Inclui templates, checklists e estudos de caso reais.',
    price: 97,
    originalPrice: 197,
    category: 'Marketing',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&h=300&fit=crop',
    author: 'João Silva',
    pages: 200,
    format: 'PDF',
    language: 'Português',
    level: 'Iniciante a Avançado',
    modules: [
      'Fundamentos do Marketing Digital',
      'SEO e Otimização para Buscadores',
      'Google Ads e Campanhas Pagas',
      'Facebook e Instagram Ads',
      'Email Marketing Eficaz',
      'Marketing de Conteúdo',
      'Analytics e Métricas',
      'Automação de Marketing'
    ],
    testimonials: [
      {
        name: 'Maria Santos',
        text: 'Excelente conteúdo! Consegui aumentar minhas vendas em 300% aplicando as estratégias.',
        rating: 5
      },
      {
        name: 'Pedro Costa',
        text: 'Muito didático e prático. Recomendo para quem quer começar no marketing digital.',
        rating: 5
      }
    ],
    faq: [
      {
        question: 'Este e-book é adequado para iniciantes?',
        answer: 'Sim! O conteúdo foi desenvolvido para atender desde iniciantes até profissionais avançados.'
      },
      {
        question: 'Recebo atualizações do conteúdo?',
        answer: 'Sim, você receberá todas as atualizações gratuitamente por email.'
      }
    ]
  },
  {
    id: '2',
    title: 'Curso: Vendas Online que Convertem',
    description: 'Domine as técnicas de vendas online e aumente sua conversão. Aprenda a criar funis de vendas eficazes e páginas que realmente vendem.',
    longDescription: 'Curso completo com mais de 50 videoaulas sobre vendas online. Aprenda a criar páginas de vendas, funis de conversão, copywriting persuasivo e técnicas de fechamento que realmente funcionam no ambiente digital.',
    price: 297,
    originalPrice: 497,
    category: 'Vendas',
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&h=300&fit=crop',
    author: 'Ana Oliveira',
    duration: '8 horas',
    format: 'Vídeo + PDF',
    language: 'Português',
    level: 'Intermediário',
    modules: [
      'Psicologia das Vendas Online',
      'Criando Páginas de Vendas',
      'Copywriting Persuasivo',
      'Funis de Conversão',
      'Técnicas de Fechamento',
      'Objeções e Como Contorná-las',
      'Automação de Vendas',
      'Métricas e Otimização'
    ],
    testimonials: [
      {
        name: 'Carlos Mendes',
        text: 'Minha taxa de conversão aumentou 250% depois deste curso!',
        rating: 5
      },
      {
        name: 'Lucia Ferreira',
        text: 'Conteúdo excepcional. Vale cada centavo investido.',
        rating: 5
      }
    ],
    faq: [
      {
        question: 'Por quanto tempo tenho acesso ao curso?',
        answer: 'Você tem acesso vitalício a todo o conteúdo do curso.'
      },
      {
        question: 'Posso assistir no celular?',
        answer: 'Sim, o conteúdo é totalmente responsivo e pode ser acessado em qualquer dispositivo.'
      }
    ]
  },
  {
    id: '3',
    title: 'Template: Landing Pages Profissionais',
    description: 'Pack com 15 templates de landing pages profissionais prontos para usar. Aumente suas conversões com designs comprovados.',
    longDescription: 'Coleção exclusiva com 15 templates de landing pages profissionais, otimizados para conversão. Inclui páginas para diferentes nichos: vendas, captura de leads, webinars, lançamentos e muito mais. Todos os templates são responsivos e fáceis de personalizar.',
    price: 147,
    originalPrice: 297,
    category: 'Templates',
    image: 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=500&h=300&fit=crop',
    author: 'Design Pro Team',
    quantity: '15 Templates',
    format: 'HTML/CSS + Figma',
    language: 'Português/Inglês',
    level: 'Todos os níveis',
    modules: [
      'Templates para Vendas',
      'Páginas de Captura',
      'Landing Pages para Webinars',
      'Páginas de Lançamento',
      'Templates para Serviços',
      'Páginas de Agradecimento',
      'Templates Mobile-First',
      'Guia de Personalização'
    ],
    testimonials: [
      {
        name: 'Roberto Lima',
        text: 'Templates incríveis! Economizei muito tempo e dinheiro.',
        rating: 5
      },
      {
        name: 'Fernanda Rocha',
        text: 'Qualidade profissional. Meus clientes adoraram!',
        rating: 5
      }
    ],
    faq: [
      {
        question: 'Preciso de conhecimento técnico para usar?',
        answer: 'Não! Os templates são fáceis de personalizar, mesmo sem conhecimento técnico.'
      },
      {
        question: 'Posso usar comercialmente?',
        answer: 'Sim, você pode usar os templates em projetos comerciais sem restrições.'
      }
    ]
  },
  {
    id: '4',
    title: 'E-book: Instagram para Negócios',
    description: 'Transforme seu Instagram em uma máquina de vendas. Estratégias práticas para crescer organicamente e monetizar sua audiência.',
    longDescription: 'Guia completo para usar o Instagram como ferramenta de negócios. Aprenda a criar conteúdo que engaja, crescer organicamente, usar Stories e Reels estrategicamente, e converter seguidores em clientes.',
    price: 67,
    originalPrice: 127,
    category: 'Redes Sociais',
    image: 'https://images.unsplash.com/photo-1611262588024-d12430b98920?w=500&h=300&fit=crop',
    author: 'Camila Torres',
    pages: 150,
    format: 'PDF + Vídeos Bônus',
    language: 'Português',
    level: 'Iniciante',
    modules: [
      'Configurando o Perfil Profissional',
      'Estratégia de Conteúdo',
      'Crescimento Orgânico',
      'Stories que Vendem',
      'Reels Virais',
      'Instagram Shopping',
      'Parcerias e Influenciadores',
      'Métricas e Analytics'
    ],
    testimonials: [
      {
        name: 'Julia Martins',
        text: 'Consegui triplicar meus seguidores em 3 meses!',
        rating: 5
      },
      {
        name: 'Marcos Souza',
        text: 'Conteúdo muito prático e atual. Recomendo!',
        rating: 5
      }
    ],
    faq: [
      {
        question: 'Funciona para qualquer nicho?',
        answer: 'Sim! As estratégias são aplicáveis a qualquer tipo de negócio.'
      },
      {
        question: 'Inclui templates prontos?',
        answer: 'Sim, você recebe templates de posts, stories e bio como bônus.'
      }
    ]
  },
  {
    id: '5',
    title: 'Curso: Copywriting Persuasivo',
    description: 'Aprenda a escrever textos que vendem. Domine as técnicas de copywriting mais eficazes para aumentar suas conversões.',
    longDescription: 'Curso completo de copywriting com foco em vendas. Aprenda a escrever headlines irresistíveis, emails que convertem, páginas de vendas persuasivas e anúncios que geram resultados.',
    price: 197,
    originalPrice: 397,
    category: 'Copywriting',
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=500&h=300&fit=crop',
    author: 'Ricardo Alves',
    duration: '6 horas',
    format: 'Vídeo + Workbook',
    language: 'Português',
    level: 'Iniciante a Intermediário',
    modules: [
      'Fundamentos do Copywriting',
      'Psicologia da Persuasão',
      'Headlines que Convertem',
      'Estruturas de Vendas',
      'Email Marketing Persuasivo',
      'Copy para Redes Sociais',
      'Testes A/B em Copy',
      'Casos Práticos'
    ],
    testimonials: [
      {
        name: 'Patricia Gomes',
        text: 'Meus emails agora têm 5x mais abertura!',
        rating: 5
      },
      {
        name: 'André Silva',
        text: 'Curso fantástico! Aprendi técnicas que uso todos os dias.',
        rating: 5
      }
    ],
    faq: [
      {
        question: 'Preciso ter experiência prévia?',
        answer: 'Não! O curso é perfeito para iniciantes e também agrega valor para quem já tem experiência.'
      },
      {
        question: 'Recebo certificado?',
        answer: 'Sim, você recebe um certificado de conclusão ao finalizar o curso.'
      }
    ]
  },
  {
    id: '6',
    title: 'E-book: Finanças Pessoais Inteligentes',
    description: 'Organize suas finanças e construa riqueza. Métodos práticos para sair das dívidas e investir com inteligência.',
    longDescription: 'Guia completo para transformar sua vida financeira. Aprenda a fazer orçamento, quitar dívidas, criar uma reserva de emergência e investir de forma inteligente para construir patrimônio.',
    price: 47,
    originalPrice: 97,
    category: 'Finanças',
    image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=500&h=300&fit=crop',
    author: 'Eduardo Santos',
    pages: 120,
    format: 'PDF + Planilhas',
    language: 'Português',
    level: 'Iniciante',
    modules: [
      'Diagnóstico Financeiro',
      'Orçamento Pessoal',
      'Quitação de Dívidas',
      'Reserva de Emergência',
      'Primeiros Investimentos',
      'Renda Passiva',
      'Planejamento de Aposentadoria',
      'Educação Financeira'
    ],
    testimonials: [
      {
        name: 'Carla Ribeiro',
        text: 'Consegui quitar todas as dívidas em 8 meses!',
        rating: 5
      },
      {
        name: 'Felipe Costa',
        text: 'Mudou completamente minha relação com o dinheiro.',
        rating: 5
      }
    ],
    faq: [
      {
        question: 'Funciona mesmo estando endividado?',
        answer: 'Sim! O método inclui estratégias específicas para quitar dívidas.'
      },
      {
        question: 'As planilhas são fáceis de usar?',
        answer: 'Sim, todas as planilhas são intuitivas e vêm com tutorial de uso.'
      }
    ]
  }
];

export const categories = [
  'Todos',
  'Marketing',
  'Vendas',
  'Templates',
  'Redes Sociais',
  'Copywriting',
  'Finanças'
];