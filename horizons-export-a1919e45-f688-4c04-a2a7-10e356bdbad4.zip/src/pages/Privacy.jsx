import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Shield, Eye, Lock, Users, FileText, Mail } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Privacy = () => {
  const sections = [
    {
      icon: FileText,
      title: 'Informações que Coletamos',
      content: [
        'Dados pessoais fornecidos voluntariamente (nome, email, telefone)',
        'Informações de pagamento (processadas por terceiros seguros)',
        'Dados de navegação e uso da plataforma',
        'Cookies e tecnologias similares para melhorar a experiência'
      ]
    },
    {
      icon: Eye,
      title: 'Como Usamos suas Informações',
      content: [
        'Processar e entregar seus pedidos',
        'Fornecer suporte ao cliente',
        'Enviar comunicações importantes sobre sua conta',
        'Melhorar nossos produtos e serviços',
        'Personalizar sua experiência na plataforma'
      ]
    },
    {
      icon: Shield,
      title: 'Proteção dos seus Dados',
      content: [
        'Criptografia SSL de 256 bits em todas as transações',
        'Servidores seguros com monitoramento 24/7',
        'Acesso restrito aos dados apenas para funcionários autorizados',
        'Backups regulares e seguros',
        'Conformidade com a LGPD (Lei Geral de Proteção de Dados)'
      ]
    },
    {
      icon: Users,
      title: 'Compartilhamento de Dados',
      content: [
        'Nunca vendemos seus dados pessoais para terceiros',
        'Compartilhamos apenas com parceiros essenciais (processadores de pagamento)',
        'Todos os parceiros seguem rigorosos padrões de segurança',
        'Você pode solicitar a exclusão dos seus dados a qualquer momento'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Política de Privacidade - EbookStore</title>
        <meta name="description" content="Conheça nossa política de privacidade e como protegemos seus dados pessoais na EbookStore." />
        <meta property="og:title" content="Política de Privacidade - EbookStore" />
        <meta property="og:description" content="Conheça nossa política de privacidade e como protegemos seus dados pessoais na EbookStore." />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <section className="hero-gradient section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-3xl mx-auto"
            >
              <Shield className="h-16 w-16 text-white mx-auto mb-6" />
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Política de Privacidade
              </h1>
              <p className="text-xl text-white/90">
                Sua privacidade é nossa prioridade. Saiba como protegemos e utilizamos seus dados.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Introduction */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Compromisso com sua Privacidade
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Na EbookStore, levamos a proteção dos seus dados pessoais muito a sério. Esta política 
                  explica como coletamos, usamos, armazenamos e protegemos suas informações quando você 
                  utiliza nossos serviços.
                </p>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-6 mb-8">
                <div className="flex items-start">
                  <Lock className="h-6 w-6 text-blue-500 mt-1 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-blue-900 mb-2">
                      Última atualização: Janeiro de 2024
                    </h3>
                    <p className="text-blue-800">
                      Esta política foi atualizada para estar em conformidade com a LGPD e as melhores 
                      práticas de proteção de dados. Recomendamos que você revise periodicamente esta página.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Main Sections */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="grid gap-8">
                {sections.map((section, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card className="bg-white shadow-lg">
                      <CardHeader>
                        <CardTitle className="flex items-center text-xl">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mr-4">
                            <section.icon className="h-6 w-6 text-white" />
                          </div>
                          {section.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-3">
                          {section.content.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex items-start">
                              <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                              <span className="text-gray-700">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Rights Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
                  Seus Direitos
                </h2>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold text-gray-900 mb-4">
                        Direitos Garantidos pela LGPD
                      </h3>
                      <ul className="space-y-2 text-gray-700">
                        <li>• Acesso aos seus dados pessoais</li>
                        <li>• Correção de dados incompletos ou incorretos</li>
                        <li>• Exclusão de dados desnecessários</li>
                        <li>• Portabilidade dos seus dados</li>
                        <li>• Revogação do consentimento</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-semibold text-gray-900 mb-4">
                        Como Exercer seus Direitos
                      </h3>
                      <ul className="space-y-2 text-gray-700">
                        <li>• Entre em contato conosco por email</li>
                        <li>• Acesse sua conta e gerencie preferências</li>
                        <li>• Solicite relatórios dos seus dados</li>
                        <li>• Cancele sua conta a qualquer momento</li>
                        <li>• Resposta em até 15 dias úteis</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Cookies Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Card className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl text-center">
                      Política de Cookies
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <p className="text-gray-700 leading-relaxed">
                      Utilizamos cookies e tecnologias similares para melhorar sua experiência em nosso site. 
                      Os cookies nos ajudam a entender como você interage com nossa plataforma e personalizar 
                      o conteúdo para você.
                    </p>
                    
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <h4 className="font-semibold text-green-800 mb-2">Cookies Essenciais</h4>
                        <p className="text-sm text-green-700">Necessários para o funcionamento básico do site</p>
                      </div>
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-semibold text-blue-800 mb-2">Cookies de Performance</h4>
                        <p className="text-sm text-blue-700">Ajudam a melhorar a velocidade e funcionalidade</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <h4 className="font-semibold text-purple-800 mb-2">Cookies de Marketing</h4>
                        <p className="text-sm text-purple-700">Personalizam anúncios e conteúdo relevante</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-2xl mx-auto"
            >
              <Mail className="h-12 w-12 text-purple-500 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Dúvidas sobre Privacidade?
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Nossa equipe está pronta para esclarecer qualquer questão sobre como tratamos seus dados.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="/contato"
                  className="btn-gradient text-white px-8 py-3 rounded-lg font-semibold transition-all hover:transform hover:scale-105"
                >
                  Entrar em Contato
                </a>
                <a
                  href="mailto:privacidade@ebookstore.com"
                  className="border-2 border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-white px-8 py-3 rounded-lg font-semibold transition-all"
                >
                  Email de Privacidade
                </a>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Privacy;