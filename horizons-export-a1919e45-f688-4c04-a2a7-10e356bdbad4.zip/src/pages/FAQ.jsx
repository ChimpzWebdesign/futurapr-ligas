import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp, Search, HelpCircle, ShoppingCart, Download, CreditCard, Shield, Users } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

const FAQ = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedItems, setExpandedItems] = useState(new Set());
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'Todas', icon: HelpCircle },
    { id: 'purchase', name: 'Compras', icon: ShoppingCart },
    { id: 'download', name: 'Downloads', icon: Download },
    { id: 'payment', name: 'Pagamentos', icon: CreditCard },
    { id: 'security', name: 'Segurança', icon: Shield },
    { id: 'account', name: 'Conta', icon: Users }
  ];

  const faqItems = [
    {
      category: 'purchase',
      question: 'Como faço para comprar um produto?',
      answer: 'Para comprar um produto, navegue pelo nosso catálogo, clique no produto desejado, adicione ao carrinho e finalize a compra preenchendo seus dados e informações de pagamento. O processo é simples e seguro.'
    },
    {
      category: 'download',
      question: 'Como acesso meus produtos após a compra?',
      answer: 'Após a confirmação do pagamento, você receberá um email com os links de download. Você também pode acessar seus produtos na área "Minha Conta" > "Downloads" a qualquer momento.'
    },
    {
      category: 'payment',
      question: 'Quais formas de pagamento vocês aceitam?',
      answer: 'Aceitamos cartões de crédito (Visa, Mastercard, American Express), PIX e boleto bancário. Para cartão de crédito, oferecemos parcelamento em até 12x sem juros para compras acima de R$ 100.'
    },
    {
      category: 'security',
      question: 'Meus dados estão seguros?',
      answer: 'Sim! Utilizamos criptografia SSL de 256 bits para proteger todas as transações. Seus dados pessoais e de pagamento são tratados com máxima segurança e nunca são compartilhados com terceiros.'
    },
    {
      category: 'purchase',
      question: 'Vocês oferecem garantia?',
      answer: 'Sim! Oferecemos garantia de satisfação de 7 dias para todos os nossos produtos. Se você não ficar satisfeito, devolvemos 100% do seu dinheiro, sem perguntas.'
    },
    {
      category: 'download',
      question: 'Por quanto tempo posso baixar meus produtos?',
      answer: 'Você tem acesso vitalício aos seus produtos. Pode baixar quantas vezes quiser, quando quiser. Recomendamos fazer backup dos arquivos em seu dispositivo.'
    },
    {
      category: 'account',
      question: 'Como criar uma conta?',
      answer: 'Você pode criar uma conta clicando em "Cadastrar" no menu superior. Preencha seus dados básicos e pronto! Você também pode criar uma conta durante o processo de compra.'
    },
    {
      category: 'payment',
      question: 'Quando meu cartão será cobrado?',
      answer: 'Seu cartão é cobrado imediatamente após a confirmação da compra. Para pagamentos parcelados, a primeira parcela é cobrada na data da compra e as demais mensalmente.'
    },
    {
      category: 'download',
      question: 'Posso baixar os produtos em qualquer dispositivo?',
      answer: 'Sim! Nossos produtos são compatíveis com computadores, tablets e smartphones. Os formatos são otimizados para funcionar em qualquer dispositivo moderno.'
    },
    {
      category: 'security',
      question: 'Como posso alterar minha senha?',
      answer: 'Acesse "Minha Conta" > "Configurações" > "Segurança" e clique em "Alterar Senha". Você precisará informar sua senha atual e definir uma nova senha.'
    },
    {
      category: 'purchase',
      question: 'Posso cancelar minha compra?',
      answer: 'Sim, você pode cancelar sua compra dentro do prazo de 7 dias da garantia. Entre em contato conosco através do email contato@ebookstore.com ou pelo formulário de contato.'
    },
    {
      category: 'account',
      question: 'Esqueci minha senha, como recuperar?',
      answer: 'Na página de login, clique em "Esqueci minha senha" e informe seu email. Você receberá um link para redefinir sua senha em alguns minutos.'
    }
  ];

  const toggleItem = (index) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedItems(newExpanded);
  };

  const filteredItems = faqItems.filter(item => {
    const matchesSearch = item.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      <Helmet>
        <title>FAQ - Perguntas Frequentes - EbookStore</title>
        <meta name="description" content="Encontre respostas para as perguntas mais frequentes sobre compras, downloads, pagamentos e muito mais na EbookStore." />
        <meta property="og:title" content="FAQ - Perguntas Frequentes - EbookStore" />
        <meta property="og:description" content="Encontre respostas para as perguntas mais frequentes sobre compras, downloads, pagamentos e muito mais na EbookStore." />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <section className="hero-gradient section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-3xl mx-auto"
            >
              <HelpCircle className="h-16 w-16 text-white mx-auto mb-6" />
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Perguntas Frequentes
              </h1>
              <p className="text-xl text-white/90">
                Encontre respostas rápidas para suas dúvidas mais comuns.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="py-8 bg-white border-b">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              {/* Search */}
              <div className="relative mb-8">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Buscar por palavra-chave..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 py-3 text-lg"
                />
              </div>

              {/* Categories */}
              <div className="flex flex-wrap gap-2 justify-center">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`flex items-center px-4 py-2 rounded-full transition-all ${
                      selectedCategory === category.id
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <category.icon className="h-4 w-4 mr-2" />
                    {category.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Items */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              {filteredItems.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-12"
                >
                  <div className="text-6xl mb-4">🔍</div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Nenhuma pergunta encontrada
                  </h3>
                  <p className="text-gray-600 mb-6">
                    Tente ajustar sua busca ou categoria selecionada.
                  </p>
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setSelectedCategory('all');
                    }}
                    className="btn-gradient text-white px-6 py-2 rounded-lg"
                  >
                    Limpar Filtros
                  </button>
                </motion.div>
              ) : (
                <div className="space-y-4">
                  {filteredItems.map((item, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: index * 0.1 }}
                    >
                      <Card className="bg-white shadow-lg hover:shadow-xl transition-shadow">
                        <CardContent className="p-0">
                          <button
                            onClick={() => toggleItem(index)}
                            className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                          >
                            <span className="font-semibold text-gray-900 pr-4">
                              {item.question}
                            </span>
                            {expandedItems.has(index) ? (
                              <ChevronUp className="h-5 w-5 text-gray-500 flex-shrink-0" />
                            ) : (
                              <ChevronDown className="h-5 w-5 text-gray-500 flex-shrink-0" />
                            )}
                          </button>
                          {expandedItems.has(index) && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              className="px-6 pb-4"
                            >
                              <p className="text-gray-600 leading-relaxed">
                                {item.answer}
                              </p>
                            </motion.div>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Contact CTA */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-2xl mx-auto"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Não encontrou sua resposta?
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Nossa equipe de suporte está pronta para ajudar você com qualquer dúvida.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="/contato"
                  className="btn-gradient text-white px-8 py-3 rounded-lg font-semibold transition-all hover:transform hover:scale-105"
                >
                  Entrar em Contato
                </a>
                <a
                  href="mailto:contato@ebookstore.com"
                  className="border-2 border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-white px-8 py-3 rounded-lg font-semibold transition-all"
                >
                  Enviar Email
                </a>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default FAQ;