import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { FileText, Scale, Shield, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Terms = () => {
  const sections = [
    {
      icon: FileText,
      title: 'Aceitação dos Termos',
      content: [
        'Ao acessar e usar a EbookStore, você concorda com estes termos',
        'Se você não concordar, não deve usar nossos serviços',
        'Podemos atualizar estes termos periodicamente',
        'O uso continuado implica aceitação das mudanças'
      ]
    },
    {
      icon: CheckCircle,
      title: 'Uso Permitido',
      content: [
        'Usar os produtos para fins pessoais e educacionais',
        'Fazer backup dos arquivos adquiridos',
        'Acessar o conteúdo em múltiplos dispositivos pessoais',
        'Compartilhar conhecimento adquirido (não os arquivos)'
      ]
    },
    {
      icon: XCircle,
      title: 'Uso Proibido',
      content: [
        'Revender, redistribuir ou compartilhar os produtos',
        'Fazer engenharia reversa ou modificar o conteúdo',
        'Usar para fins comerciais sem autorização',
        'Violar direitos autorais ou propriedade intelectual'
      ]
    },
    {
      icon: Shield,
      title: 'Propriedade Intelectual',
      content: [
        'Todo conteúdo é protegido por direitos autorais',
        'Você adquire licença de uso, não propriedade',
        'Marcas registradas pertencem aos respectivos proprietários',
        'Violações podem resultar em ações legais'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Termos de Uso - EbookStore</title>
        <meta name="description" content="Leia nossos termos de uso e condições para utilização da plataforma EbookStore." />
        <meta property="og:title" content="Termos de Uso - EbookStore" />
        <meta property="og:description" content="Leia nossos termos de uso e condições para utilização da plataforma EbookStore." />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <section className="hero-gradient section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-3xl mx-auto"
            >
              <Scale className="h-16 w-16 text-white mx-auto mb-6" />
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Termos de Uso
              </h1>
              <p className="text-xl text-white/90">
                Condições e diretrizes para o uso da nossa plataforma e produtos.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Introduction */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Bem-vindo aos Nossos Termos
                </h2>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Estes termos de uso estabelecem as regras e condições para utilização da EbookStore. 
                  Ao usar nossos serviços, você concorda em cumprir estes termos e todas as leis aplicáveis.
                </p>
              </div>

              <div className="bg-amber-50 border-l-4 border-amber-500 p-6 mb-8">
                <div className="flex items-start">
                  <AlertCircle className="h-6 w-6 text-amber-500 mt-1 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-amber-900 mb-2">
                      Importante: Leia Atentamente
                    </h3>
                    <p className="text-amber-800">
                      Estes termos constituem um acordo legal entre você e a EbookStore. 
                      Certifique-se de compreender todas as condições antes de usar nossos serviços.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Main Sections */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="grid gap-8">
                {sections.map((section, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card className="bg-white shadow-lg">
                      <CardHeader>
                        <CardTitle className="flex items-center text-xl">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mr-4">
                            <section.icon className="h-6 w-6 text-white" />
                          </div>
                          {section.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-3">
                          {section.content.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex items-start">
                              <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                              <span className="text-gray-700">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Detailed Terms */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Card className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl">Compras e Pagamentos</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Preços e Disponibilidade</h4>
                      <p className="text-gray-700">
                        Os preços estão sujeitos a alterações sem aviso prévio. Nos reservamos o direito 
                        de modificar ou descontinuar produtos a qualquer momento.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Processamento de Pagamentos</h4>
                      <p className="text-gray-700">
                        Todos os pagamentos são processados de forma segura através de parceiros certificados. 
                        Você é responsável por fornecer informações de pagamento precisas e atualizadas.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Política de Reembolso</h4>
                      <p className="text-gray-700">
                        Oferecemos garantia de 7 dias para todos os produtos. Reembolsos são processados 
                        no método de pagamento original em até 10 dias úteis.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <Card className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl">Responsabilidades do Usuário</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Conta do Usuário</h4>
                      <p className="text-gray-700">
                        Você é responsável por manter a confidencialidade da sua conta e senha. 
                        Notifique-nos imediatamente sobre qualquer uso não autorizado.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Conduta Apropriada</h4>
                      <p className="text-gray-700">
                        Você concorda em usar nossos serviços de forma legal e respeitosa, 
                        sem violar direitos de terceiros ou prejudicar nossa plataforma.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Informações Precisas</h4>
                      <p className="text-gray-700">
                        Você deve fornecer informações verdadeiras, precisas e atualizadas 
                        ao criar sua conta e fazer compras.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <Card className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl">Limitação de Responsabilidade</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Isenção de Garantias</h4>
                      <p className="text-gray-700">
                        Os produtos são fornecidos "como estão". Não garantimos que atendam 
                        às suas expectativas específicas ou produzam resultados particulares.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Limitação de Danos</h4>
                      <p className="text-gray-700">
                        Nossa responsabilidade é limitada ao valor pago pelo produto. 
                        Não somos responsáveis por danos indiretos ou consequenciais.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Disponibilidade do Serviço</h4>
                      <p className="text-gray-700">
                        Embora nos esforcemos para manter o serviço disponível, não garantimos 
                        operação ininterrupta ou livre de erros.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-2xl mx-auto"
            >
              <FileText className="h-12 w-12 text-purple-500 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Dúvidas sobre os Termos?
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Se você tiver alguma dúvida sobre estes termos de uso, entre em contato conosco.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="/contato"
                  className="btn-gradient text-white px-8 py-3 rounded-lg font-semibold transition-all hover:transform hover:scale-105"
                >
                  Entrar em Contato
                </a>
                <a
                  href="mailto:legal@ebookstore.com"
                  className="border-2 border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-white px-8 py-3 rounded-lg font-semibold transition-all"
                >
                  Email Jurídico
                </a>
              </div>
              
              <div className="mt-8 p-4 bg-gray-100 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Última atualização:</strong> Janeiro de 2024<br />
                  <strong>Versão:</strong> 2.1<br />
                  <strong>Jurisdição:</strong> Brasil
                </p>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Terms;