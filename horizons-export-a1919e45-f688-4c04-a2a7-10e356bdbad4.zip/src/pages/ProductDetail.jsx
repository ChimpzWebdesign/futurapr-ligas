import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, ShoppingCart, Download, Clock, BookOpen, Globe, Award, ChevronDown, ChevronUp, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/components/ui/use-toast';
import { products } from '@/data/products';

const ProductDetail = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [expandedFaq, setExpandedFaq] = useState(null);

  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Produto não encontrado</h1>
          <Link to="/catalogo">
            <Button className="btn-gradient text-white">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar ao Catálogo
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: "Produto adicionado!",
      description: `${product.title} foi adicionado ao seu carrinho.`,
    });
  };

  const toggleFaq = (index) => {
    setExpandedFaq(expandedFaq === index ? null : index);
  };

  return (
    <>
      <Helmet>
        <title>{product.title} - EbookStore</title>
        <meta name="description" content={product.description} />
        <meta property="og:title" content={`${product.title} - EbookStore`} />
        <meta property="og:description" content={product.description} />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Breadcrumb */}
        <div className="bg-white border-b">
          <div className="container mx-auto px-4 py-4">
            <nav className="flex items-center space-x-2 text-sm text-gray-600">
              <Link to="/" className="hover:text-purple-600">Início</Link>
              <span>/</span>
              <Link to="/catalogo" className="hover:text-purple-600">Catálogo</Link>
              <span>/</span>
              <span className="text-gray-900">{product.title}</span>
            </nav>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Product Image */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="relative">
                <img  
                  alt={product.title}
                  className="w-full rounded-2xl shadow-2xl"
                 src="https://images.unsplash.com/photo-1671376354106-d8d21e55dddd" />
                {product.originalPrice && (
                  <div className="absolute top-6 right-6 bg-red-500 text-white px-4 py-2 rounded-lg text-lg font-bold">
                    -{Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
                  </div>
                )}
              </div>
            </motion.div>

            {/* Product Info */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-6"
            >
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {product.category}
                  </span>
                </div>
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                  {product.title}
                </h1>
                <div className="flex items-center space-x-4 mb-4">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                  <span className="text-gray-600">(4.9) • 1.234 avaliações</span>
                </div>
                <p className="text-lg text-gray-600 leading-relaxed">
                  {product.longDescription}
                </p>
              </div>

              {/* Price */}
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    {product.originalPrice && (
                      <div className="text-lg text-gray-500 line-through">
                        De R$ {product.originalPrice}
                      </div>
                    )}
                    <div className="text-3xl font-bold text-gray-900">
                      R$ {product.price}
                    </div>
                    <div className="text-sm text-gray-600">
                      ou 12x de R$ {(product.price / 12).toFixed(2)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Por: {product.author}</div>
                  </div>
                </div>
                
                <Button 
                  onClick={handleAddToCart}
                  className="w-full btn-gradient text-white text-lg py-3 mb-4"
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Adicionar ao Carrinho
                </Button>
                
                <div className="text-center text-sm text-gray-600">
                  ✅ Acesso imediato após a compra<br />
                  ✅ Garantia de 7 dias<br />
                  ✅ Suporte especializado
                </div>
              </div>

              {/* Product Details */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-lg p-4 text-center">
                  <BookOpen className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <div className="font-semibold text-gray-900">
                    {product.pages ? `${product.pages} páginas` : product.duration || product.quantity}
                  </div>
                  <div className="text-sm text-gray-600">Conteúdo</div>
                </div>
                <div className="bg-white rounded-lg p-4 text-center">
                  <Download className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <div className="font-semibold text-gray-900">{product.format}</div>
                  <div className="text-sm text-gray-600">Formato</div>
                </div>
                <div className="bg-white rounded-lg p-4 text-center">
                  <Globe className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <div className="font-semibold text-gray-900">{product.language}</div>
                  <div className="text-sm text-gray-600">Idioma</div>
                </div>
                <div className="bg-white rounded-lg p-4 text-center">
                  <Award className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <div className="font-semibold text-gray-900">{product.level}</div>
                  <div className="text-sm text-gray-600">Nível</div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Content Modules */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mt-16"
          >
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 text-center">
              O que você vai aprender
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {product.modules.map((module, index) => (
                <div key={index} className="bg-white rounded-lg p-6 shadow-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold">
                      {index + 1}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">{module}</h3>
                  </div>
                </div>
              ))}
            </div>
          </motion.section>

          {/* Testimonials */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mt-16"
          >
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 text-center">
              Depoimentos
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              {product.testimonials.map((testimonial, index) => (
                <Card key={index} className="bg-white shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex text-yellow-400 mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-current" />
                      ))}
                    </div>
                    <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.section>

          {/* FAQ */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mt-16"
          >
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 text-center">
              Perguntas Frequentes
            </h2>
            <div className="max-w-3xl mx-auto space-y-4">
              {product.faq.map((item, index) => (
                <div key={index} className="bg-white rounded-lg shadow-lg">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50"
                  >
                    <span className="font-semibold text-gray-900">{item.question}</span>
                    {expandedFaq === index ? (
                      <ChevronUp className="h-5 w-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-500" />
                    )}
                  </button>
                  {expandedFaq === index && (
                    <div className="px-6 pb-4">
                      <p className="text-gray-600">{item.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.section>

          {/* CTA Section */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mt-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-8 text-center text-white"
          >
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              Pronto para começar?
            </h2>
            <p className="text-lg mb-6 opacity-90">
              Não perca mais tempo! Transforme seu conhecimento em resultados hoje mesmo.
            </p>
            <Button 
              onClick={handleAddToCart}
              size="lg"
              className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8 py-3"
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              Comprar Agora - R$ {product.price}
            </Button>
          </motion.section>
        </div>
      </div>
    </>
  );
};

export default ProductDetail;