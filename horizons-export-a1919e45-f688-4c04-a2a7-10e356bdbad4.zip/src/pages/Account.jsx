import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Download, ShoppingBag, Settings, LogOut, Eye, Calendar, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const Account = () => {
  const { user, updateUser, logout } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || ''
  });

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSaveProfile = () => {
    updateUser(formData);
    setIsEditing(false);
    toast({
      title: "Perfil atualizado!",
      description: "Suas informações foram salvas com sucesso.",
    });
  };

  const handleCancelEdit = () => {
    setFormData({
      name: user.name || '',
      email: user.email || '',
      phone: user.phone || ''
    });
    setIsEditing(false);
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
  };

  const tabs = [
    { id: 'profile', name: 'Perfil', icon: User },
    { id: 'purchases', name: 'Minhas Compras', icon: ShoppingBag },
    { id: 'downloads', name: 'Downloads', icon: Download },
    { id: 'settings', name: 'Configurações', icon: Settings }
  ];

  const purchases = user.purchases || [];

  return (
    <>
      <Helmet>
        <title>Minha Conta - EbookStore</title>
        <meta name="description" content="Gerencie sua conta, visualize suas compras e faça downloads dos seus produtos" />
        <meta property="og:title" content="Minha Conta - EbookStore" />
        <meta property="og:description" content="Gerencie sua conta, visualize suas compras e faça downloads dos seus produtos" />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <section className="bg-white border-b">
          <div className="container mx-auto px-4 py-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center justify-between"
            >
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                  Minha Conta
                </h1>
                <p className="text-xl text-gray-600">
                  Olá, {user.name}! Gerencie sua conta e acesse seus produtos.
                </p>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                <LogOut className="mr-2 h-4 w-4" />
                Sair
              </Button>
            </motion.div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Card className="bg-white shadow-lg">
                <CardContent className="p-0">
                  <nav className="space-y-1">
                    {tabs.map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-full flex items-center px-6 py-4 text-left hover:bg-gray-50 transition-colors ${
                          activeTab === tab.id
                            ? 'bg-purple-50 text-purple-600 border-r-2 border-purple-600'
                            : 'text-gray-600'
                        }`}
                      >
                        <tab.icon className="h-5 w-5 mr-3" />
                        {tab.name}
                      </button>
                    ))}
                  </nav>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              {activeTab === 'profile' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <Card className="bg-white shadow-lg">
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle>Informações do Perfil</CardTitle>
                        {!isEditing ? (
                          <Button
                            onClick={() => setIsEditing(true)}
                            variant="outline"
                          >
                            Editar
                          </Button>
                        ) : (
                          <div className="space-x-2">
                            <Button
                              onClick={handleSaveProfile}
                              className="btn-gradient text-white"
                            >
                              Salvar
                            </Button>
                            <Button
                              onClick={handleCancelEdit}
                              variant="outline"
                            >
                              Cancelar
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="flex items-center space-x-4">
                        <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-2xl">
                            {user.name?.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900">{user.name}</h3>
                          <p className="text-gray-600">Cliente desde {new Date(user.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="name">Nome Completo</Label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div>
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone">Telefone</Label>
                          <Input
                            id="phone"
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div>
                          <Label>Status da Conta</Label>
                          <div className="flex items-center mt-2">
                            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                            <span className="text-green-600 font-medium">Ativa</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {activeTab === 'purchases' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <Card className="bg-white shadow-lg">
                    <CardHeader>
                      <CardTitle>Histórico de Compras</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {purchases.length === 0 ? (
                        <div className="text-center py-8">
                          <ShoppingBag className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                          <h3 className="text-lg font-medium text-gray-900 mb-2">
                            Nenhuma compra realizada
                          </h3>
                          <p className="text-gray-600 mb-6">
                            Explore nosso catálogo e encontre produtos incríveis!
                          </p>
                          <Link to="/catalogo">
                            <Button className="btn-gradient text-white">
                              Explorar Produtos
                            </Button>
                          </Link>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {purchases.map((purchase) => (
                            <div key={purchase.id} className="border rounded-lg p-4">
                              <div className="flex justify-between items-start mb-3">
                                <div>
                                  <h4 className="font-semibold text-gray-900">
                                    Pedido #{purchase.id}
                                  </h4>
                                  <div className="flex items-center text-sm text-gray-600 mt-1">
                                    <Calendar className="h-4 w-4 mr-1" />
                                    {new Date(purchase.date).toLocaleDateString()}
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="text-lg font-bold text-gray-900">
                                    R$ {purchase.total.toFixed(2)}
                                  </div>
                                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    Concluído
                                  </span>
                                </div>
                              </div>
                              <div className="space-y-2">
                                {purchase.items.map((item) => (
                                  <div key={item.id} className="flex justify-between items-center text-sm">
                                    <span className="text-gray-900">{item.title}</span>
                                    <span className="text-gray-600">
                                      {item.quantity}x R$ {item.price}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {activeTab === 'downloads' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <Card className="bg-white shadow-lg">
                    <CardHeader>
                      <CardTitle>Meus Downloads</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {purchases.length === 0 ? (
                        <div className="text-center py-8">
                          <Download className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                          <h3 className="text-lg font-medium text-gray-900 mb-2">
                            Nenhum produto para download
                          </h3>
                          <p className="text-gray-600 mb-6">
                            Seus produtos aparecerão aqui após a compra.
                          </p>
                          <Link to="/catalogo">
                            <Button className="btn-gradient text-white">
                              Explorar Produtos
                            </Button>
                          </Link>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {purchases.flatMap(purchase => 
                            purchase.items.map(item => (
                              <div key={`${purchase.id}-${item.id}`} className="flex items-center justify-between p-4 border rounded-lg">
                                <div className="flex items-center space-x-4">
                                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                                    <Download className="h-6 w-6 text-white" />
                                  </div>
                                  <div>
                                    <h4 className="font-medium text-gray-900">{item.title}</h4>
                                    <p className="text-sm text-gray-600">{item.format}</p>
                                  </div>
                                </div>
                                <Button
                                  onClick={() => toast({
                                    title: "🚧 Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
                                  })}
                                  className="btn-gradient text-white"
                                >
                                  <Download className="h-4 w-4 mr-2" />
                                  Baixar
                                </Button>
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <Card className="bg-white shadow-lg">
                    <CardHeader>
                      <CardTitle>Configurações da Conta</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="border-b pb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">Notificações</h3>
                        <div className="space-y-3">
                          <label className="flex items-center">
                            <input type="checkbox" defaultChecked className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                            <span className="ml-3 text-gray-700">Receber emails sobre novos produtos</span>
                          </label>
                          <label className="flex items-center">
                            <input type="checkbox" defaultChecked className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                            <span className="ml-3 text-gray-700">Receber emails promocionais</span>
                          </label>
                          <label className="flex items-center">
                            <input type="checkbox" className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                            <span className="ml-3 text-gray-700">Receber SMS sobre pedidos</span>
                          </label>
                        </div>
                      </div>

                      <div className="border-b pb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">Segurança</h3>
                        <div className="space-y-3">
                          <Button
                            onClick={() => toast({
                              title: "🚧 Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
                            })}
                            variant="outline"
                          >
                            Alterar Senha
                          </Button>
                          <Button
                            onClick={() => toast({
                              title: "🚧 Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
                            })}
                            variant="outline"
                          >
                            Ativar Autenticação em Duas Etapas
                          </Button>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-medium text-gray-900 mb-4">Zona de Perigo</h3>
                        <Button
                          onClick={() => toast({
                            title: "🚧 Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
                          })}
                          variant="outline"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                        >
                          Excluir Conta
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Account;