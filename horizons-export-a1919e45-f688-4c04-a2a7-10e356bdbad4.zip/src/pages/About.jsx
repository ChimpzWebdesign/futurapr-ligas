import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Users, Target, Award, Heart, Zap, Shield } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const About = () => {
  const values = [
    {
      icon: Target,
      title: 'Foco no Cliente',
      description: 'Colocamos nossos clientes no centro de tudo que fazemos, oferecendo produtos que realmente agregam valor.'
    },
    {
      icon: Award,
      title: 'Qualidade Premium',
      description: 'Todos os nossos produtos passam por rigorosa curadoria para garantir a melhor experiência de aprendizado.'
    },
    {
      icon: Zap,
      title: 'Inovação Constante',
      description: 'Estamos sempre buscando novas formas de entregar conhecimento de maneira mais eficaz e acessível.'
    },
    {
      icon: Shield,
      title: 'Confiança e Segurança',
      description: 'Garantimos transações seguras e proteção total dos dados dos nossos clientes.'
    }
  ];

  const team = [
    {
      name: 'Ana Silva',
      role: 'CEO & Fundadora',
      description: 'Especialista em educação digital com mais de 10 anos de experiência no mercado.',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop&crop=face'
    },
    {
      name: 'Carlos Santos',
      role: 'Diretor de Conteúdo',
      description: 'Responsável pela curadoria e qualidade de todos os produtos da plataforma.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face'
    },
    {
      name: 'Maria Oliveira',
      role: 'Gerente de Marketing',
      description: 'Especialista em marketing digital e estratégias de crescimento.',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=300&fit=crop&crop=face'
    }
  ];

  const stats = [
    { number: '50.000+', label: 'Clientes Ativos' },
    { number: '1.000+', label: 'Produtos Vendidos' },
    { number: '98%', label: 'Satisfação' },
    { number: '5 Anos', label: 'No Mercado' }
  ];

  return (
    <>
      <Helmet>
        <title>Sobre Nós - EbookStore</title>
        <meta name="description" content="Conheça a história da EbookStore, nossa missão e os valores que nos guiam na criação dos melhores e-books e infoprodutos." />
        <meta property="og:title" content="Sobre Nós - EbookStore" />
        <meta property="og:description" content="Conheça a história da EbookStore, nossa missão e os valores que nos guiam na criação dos melhores e-books e infoprodutos." />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <section className="hero-gradient section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto"
            >
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Nossa História
              </h1>
              <p className="text-xl text-white/90 leading-relaxed">
                Nascemos da paixão por democratizar o conhecimento e transformar vidas através da educação digital. 
                Há mais de 5 anos, conectamos pessoas aos melhores conteúdos educacionais do mercado.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="section-padding bg-white">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                  Nossa Missão
                </h2>
                <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                  Acreditamos que o conhecimento é a chave para transformar vidas e construir um futuro melhor. 
                  Nossa missão é tornar o aprendizado acessível, prático e transformador para todos.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Trabalhamos incansavelmente para curar os melhores conteúdos, conectar você com especialistas 
                  renomados e oferecer uma experiência de aprendizado excepcional.
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                <img  
                  alt="Equipe colaborando em escritório moderno"
                  className="rounded-2xl shadow-2xl w-full"
                 src="https://images.unsplash.com/photo-1522071820081-009f0129c71c" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="section-padding bg-gray-50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Nossos Valores
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Os princípios que guiam cada decisão e ação em nossa jornada.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="card-hover h-full bg-white border-0 shadow-lg text-center">
                    <CardContent className="p-6">
                      <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <value.icon className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-3">
                        {value.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="section-padding bg-white">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Nossos Números
              </h2>
              <p className="text-xl text-gray-600">
                Resultados que comprovam nosso compromisso com a excelência.
              </p>
            </motion.div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-600 text-lg">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="section-padding bg-gray-50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Nossa Equipe
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Conheça as pessoas apaixonadas que tornam tudo isso possível.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {team.map((member, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="card-hover bg-white border-0 shadow-lg text-center">
                    <CardContent className="p-6">
                      <img  
                        alt={`Foto de ${member.name}`}
                        className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                       src="https://images.unsplash.com/photo-1494790108755-2616b612b786" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-1">
                        {member.name}
                      </h3>
                      <p className="text-purple-600 font-medium mb-3">
                        {member.role}
                      </p>
                      <p className="text-gray-600 leading-relaxed">
                        {member.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="hero-gradient section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-3xl mx-auto"
            >
              <Heart className="h-16 w-16 text-white mx-auto mb-6" />
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                Junte-se à Nossa Comunidade
              </h2>
              <p className="text-xl text-white/90 mb-8">
                Faça parte de uma comunidade que valoriza o conhecimento e a transformação pessoal.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="/catalogo" className="btn-gradient bg-white text-purple-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-semibold transition-all">
                  Explorar Produtos
                </a>
                <a href="/contato" className="border-2 border-white text-white hover:bg-white hover:text-purple-600 px-8 py-3 rounded-lg font-semibold transition-all">
                  Fale Conosco
                </a>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default About;